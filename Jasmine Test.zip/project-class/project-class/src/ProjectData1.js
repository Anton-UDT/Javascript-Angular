	/**
     * Class
	 **/
function ProjectData(projectName) {
	this.projectName = projectName;
	if(projectName == "BC") {
		this.projectData = BCdata;
	}
	else if(projectName == "RT") {
		this.projectData = RTdata;
	}
	else if(projectName == "CM") {
		this.projectData = CMdata;
	}
	else if(projectName == "CQ") {
		this.projectData = CQdata;
	}
	else if(projectName == "HH") {
		this.projectData = HHdata;
	}
	else if(projectName == "V") {
		this.projectData = Vdata;
	}
	
}

ProjectData.prototype.getPageData = function() {
	return this.backgroundImage;
	return this.photoCredit;
	return this.logoFile;
	return this.aboutText;
	return this.statistics;
	return this.soundFile;
}

ProjectData.prototype.getStatistics = function() {
	return this.statistics;	
}

ProjectData.prototype.getFooter = function(footerNum) {	
	if (footerNum == 1) {
		return this.footer1;
	} else if (footerNum == 2) {
		return this.footer2;
	} else if (footerNum == 3) {
		return this.footer3;
	} else {
		return "Incorrect footer number";
	}
}

ProjectData.prototype.getGallery = function() {
	return this.Gallery;
}


/*******************************
*	Restoration Trust Tests	*
********************************/
describe("RT, ProjectData:", function() {
	var pageData = new ProjectData("RT");

	it("RT, Should create new projectData", function() {
		expect(pageData.projectName).toBe("RT");
	});
	it("RT, Background Image to be background-restoration-trust.png", function() {
		expect(pageData.projectData.backgroundImage).toBe("images/backgrounds/background-restoration-trust.png");
		console.log("RT, Background:", pageData.projectData.backgroundImage);	
	});
	it("RT, Photo credits to be 'Restoration Trust - Restoration Trust'", function(){
		expect(pageData.projectData.photoCredit).toBe("Restoration Trust - Restoration Trust");
		console.log("RT, Photo credits:", pageData.projectData.photoCredit);
	});
	it("RT, Logo file path should be 'Report content/logos/RestorationTrust_Logo Square.jpg'", function(){
		expect(pageData.projectData.logoFile).toBe("Report content/logos/RestorationTrust_Logo Square.jpg");
		console.log("RT, Logo file:", pageData.projectData.logoFile);
	});
	it("RT, About text should be aload of html", function(){
		expect(pageData.projectData.aboutText).toBe("<span class='heading'>Restoration Trust</span><span class='text-super'>&copy;</span><br/>" +
       "We help people with mental health problems engage with heritage, art and culture in a creative, safe way." +
       "We call it culture therapy <span class='text-super'>&copy;</span>.<br/><br/>" +
       "Our vision:<br/><ul list-style='none'>" + 
       "<li>By 2027 culture therapy will be everyday good practice in mental health and culture.</li></ul><br/><br/>" +
       "We aim to:<ul list-style='square'><li>enable, broker and develop partnerships</li>" +
       "<li>incubate and test new ideas</li><li>co-produce projects together with participants and partners</li>" +
       "<li>work with people who have severe mental health problems</li>" +
       "<li>deliver long-term sustained engagement that become part of people\'s lives</li>" + 
       "<li>challenge heritage and cultural education and outreach services</li></ul><br/><br/>" +    
       "Our approach:<ul list-style='square'>" +
       "<li>Groupwork is the core</li><li>Sustained engagement and regular sessions</li>" +
       "<li>Exceptional, exciting, exacting cultural experiences</li>" +
       "<li>Creative expression where imagination meets inspiration</li>" +
       "<li>Safe framework to the highest standards of mental health practice</li>" +
       "<li>Measuring impact and outcomes to build knowledge and keep learning</li>" +
       "<li>Progression that suits participants’ individual wishes</li><br/><br/>" +
       "</ul>");
	});
	it("RT, Empty statistics array", function(){
		expect(pageData.projectData.statistics).toEqual([]);
		console.log("RT, statistics:", pageData.projectData.statistics)
	});
	it("RT, Sound File", function(){
		expect(pageData.projectData.soundFile).toBe("");
	});
	it("RT, Footer1 stuff", function(){
		expect(pageData.projectData.footer1html).toBe("");
	});
	it("RT, Footer2 stuff", function(){
		expect(pageData.projectData.footer2html).toBe("");
	});
	it("RT, Footer3 stuff", function(){
		expect(pageData.projectData.footer3html).toBe("");
	});
	it("RT, social media link`s", function(){
		expect(pageData.projectData.socialMediaLinks).toBe("https://www.instagram.com/restorationtrust/");
	});
});
/*****************************
*	Human Henge Tests	*
*****************************/
describe("HH, ProjectData:", function(){
	var pageData = new ProjectData("HH");
	
	it("HH, Should create new projectData", function() {
		expect(pageData.projectName).toBe("HH");
	});
	it("HH, Background Image to be background-human-henge.png", function() {
		expect(pageData.projectData.backgroundImage).toBe("images/backgrounds/background-human-henge.png");
		console.log("HH, Background:", pageData.projectData.backgroundImage);	
	});
	it("HH, Photo credits", function(){
		expect(pageData.projectData.photoCredit).toBe("Human Henge - Jessie Swinburne");
	});
	it("HH, Logo File", function(){
		expect(pageData.projectData.logoFile).toBe("Report content/logos/HH_Logo.");
	});
	it("HH, Photo credits", function(){
		expect(pageData.projectData.photoCredit).toBe("Human Henge - Jessie Swinburne");
	});
	it("HH, About text", function(){
		expect(pageData.projectData.aboutText).toBe("<span class='heading'>Human Henge<span class='text-super'>&copy;</span></span><br/>" +
        "Walking with intent in Stonehenge\'s ancient landscape<br/><br/>" + 
        "<span class='heading'>Partners</span><br/>" +
        "English Heritage, Richmond Fellowship, Bournemouth University, National Trust, Avon and Wiltshire Mental Health Partnership Trust");
	});
	it("HH, Statistics", function(){
		expect(pageData.projectData.Statistics).toEqual([
                    {"stat":"20","context":" Sessions"},
                    {"stat":"25","context":" Participants"},
                    {"stat":"4","context":" Volunteers"},
                    {"stat":"1.27","context":" million people listened to Radio 4 Open Country Stonehenge and mental health"},
                    {"stat":"£520,344","context":" Social value"}
	              ],
		);
		console.log("HH, Statistics:", pageData.projectData.Statistics);
	});
	it("HH, sound File", function(){
		expect(pageData.projectData.soundFile).toBe("Simon HH interview.wav");
	});
	it("HH, Footer1 stuff", function(){
		expect(pageData.projectData.footer1html).toBe("");
	});
	it("HH, Footer2 stuff", function(){
		expect(pageData.projectData.footer2html).toBe("");
	});
	it("HH, Footer3 stuff", function(){
		expect(pageData.projectData.footer3html).toBe("");
	});
	it("HH, Gallery", function(){
		expect(pageData.projectData.Gallery).toEqual([
                   { "filename":"images/human_henge_images/HH_A_taste_of_neolithic_life_-_Mr_BPD.jpg","caption":"A taste of neolithic life - Mr BPD"},
                   { "filename":"images/human_henge_images/HH_Cohort_1_Session_10_Winter_Solstice_Final_Ceremony_-_Jessie_Swinburne_-_Copy.jpg","caption":"Winter Solstice Final Ceremony - Jessie Swinburne"},
                   { "filename":"images/human_henge_images/HH_Cohort_1_Session_10_Winter_Solstice_Final_Ceremony_-_Jessie_Swinburne.jpg","caption":"Winter Solstice Final Ceremony - Jessie Swinburne"},
                   { "filename":"images/human_henge_images/HH_Cohort_1_Session_10_Winter_Solstice_Final_Ceremony2_-_Jessie_Swinburne.jpg","caption":"Winter Solstice Final Ceremony - Jessie Swinburne"},
                   { "filename":"images/human_henge_images/HH_Cohort_1_Session_4_Singing_and_learning_with_the_ancestors2_-_Yvette_Staelens.jpg","caption":"Singing and learning with the ancestors - Yvette Staelens"},
                   { "filename":"images/human_henge_images/HH_Cohort_1_Session_6_visit_to_Neolithic_houses_-_Yvette_Staelens.jpg","caption":"Visit to Neolithic houses - Yvette Staelens"},
                   { "filename":"images/human_henge_images/HH_Cohort_1_Session_6_visit_to_Neolithic_houses2_-_Yvette_Staelens.jpg","caption":"Visit to Neolithic houses - Yvette Staelens"},
                   { "filename":"images/human_henge_images/HH_Cohort_1_Session_7_Pottery_workshop_-_Yvette_Staelens.jpg","caption":"Pottery workshop - Yvette Staelens"},
                   { "filename":"images/human_henge_images/HH_Cohort_2_Session_10_Spring_Equinox-Yvette_Staelens.jpg","caption":"Spring Equinox -Yvette Staelens"},
                   { "filename":"images/human_henge_images/HH_Cohort_2_Session_3_Visit_to_Fargo_wood_-_Mr_BPD.jpg","caption":"Visit to Fargo wood - Mr BPD"},
                   { "filename":"images/human_henge_images/HH_Cohort2_Session_7_Pottery_workshop_-_Yvette_Staelens.jpg","caption":"Pottery workshop - Yvette Staelens"},
                   { "filename":"images/human_henge_images/HH_Human_Henge_book_-_Restoration_Trust_JPG.JPG","caption":"Human Henge book - Restoration Trust"},
                   { "filename":"images/human_henge_images/HH_Human_Henge_celebration_picnic_-_Johnny_Tipler.jpg","caption":"Celebration picnic - Johnny Tipler"},
                   { "filename":"images/human_henge_images/HH_Neolithic_man_in_action_-_Laura_Drysdale.JPG","caption":"Neolithic man in action - Yvette Staelens"},
                   { "filename":"images/human_henge_images/HH_Stone_Henge_visitors_centre_-_Chris_Hogg.jpg","caption":"Stone Henge visitor centre - Chris Hogg"},
                   { "filename":"images/human_henge_images/HH_Cohort2_Participant_Artwork_-_Melanie_Rodgers.jpg","caption":"Art by Melanie Rodgers"}
	            ]);
		console.log("HH, Gallery:", pageData.projectData.Gallery);
		});
		it("HH, Video name", function(){
			expect(pageData.projectData.videoName).toBe("");
		});
	
});
/********************
*	Voyagers Test	*
*********************/
describe("V, ProjectData:", function(){
	var pageData = new ProjectData("V");
	it("V, Should create new projectData", function() {
		expect(pageData.projectName).toBe("V");
	});
	it("V, Background image", function(){
		expect(pageData.projectData.backgroundImage).toBe("images/backgrounds/background-voyagers.png");
	});
	it("V, Photo credit", function(){
		expect(pageData.projectData.photoCredit).toBe("Voyagers - Melanie Tilford");
	});
	it("V, Logo file", function(){
		expect(pageData.projectData.logoFile).toBe("Report content/logos/logoblue4.psd");
	});
	it("V, Logo link", function(){
		expect(pageData.projectData.logoLink).toBe("");
	});
	it("V, About text", function(){
		expect(pageData.projectData.aboutText).toBe("");
	});
	it("V, Statistics", function(){
		expect(pageData.projectData.statistics).toEqual([
                    {"stat":"5","context":" Sessions"},
                    {"stat":"18","context":" Participants"},
                    {"stat":"4","context":" Volunteers"},
                    {"stat":"10","context":" people spent the day at the Fitzwilliam Museum"},
                    {"stat":"£11,851","context":" Social value"}
	              ]);
	              console.log("V, Statistics:", pageData.projectData.statistics);
	});
	it("V, Sound file", function(){
		expect(pageData.projectData.soundFile).toBe("VOYAGERS_Leslie interview for RT annual report.wav");
	});
	it("V, Footer1 stuff", function(){
		expect(pageData.projectData.footer1html).toBe("");
	});
	it("V, Footer2 stuff", function(){
		expect(pageData.projectData.footer2html).toBe("");
	});
	it("V, Footer3 stuff", function(){
		expect(pageData.projectData.footer3html).toBe("");
	});
	it("V, Gallery", function(){
		expect(pageData.projectData.gallery).toEqual([
                   { "filename":"images/voyagers_images/V_BritishArtShow8-NorwichCastleMuseum-TashaWinton.jpg","caption":"British Art Show, Norwich Castle Museum - Tasha Winton"},
                   { "filename":"images/voyagers_images/V_Drawing_of_Judge_Business_School_Cambridge_-_Rachel_Dorling.jpg","caption":"Drawing of Judge Business School by Rachel Dorling"},
                   { "filename":"images/voyagers_images/V_Houghton_Hall_-_Laura_Drysdale.JPG","caption":"Trip to Houghton Hall - Restoration Trust"},
                   { "filename":"images/voyagers_images/V_Trip_to_Fitzwilliam_Musuem_Cambridge_-_April2017_-_Melanie_Tilford.jpg","caption":"Trip to Fitzwilliam Museum, Cambridge, Madonnas and Miracles exhibition - Melanie Tilford"},
                   { "filename":"images/voyagers_images/V_Trip_to_Fitzwilliam_Musuem_Cambridge_Madonnas_and_Miracles_exhibition_-_April2017_-_Melanie_Tilford.jpg","caption":"Trip to Fitzwilliam Museum, Cambridge, Madonnas and Miracles exhibition - Melanie Tilford"},
                   { "filename":"images/voyagers_images/V_Trip_to_Houghton_Hall_Sculpture_park2_-_Sept2016_-_Melanie_Tilford.jpg","caption":"Trip to Houghton Hall Sculpture park - Melanie Tilford"},
                   { "filename":"images/voyagers_images/V_Trip_to_Norwich_Castle_Museum_Small_Stories_exhibition2_-_March2017_-_Tasha_Winton.jpg","caption":"Trip to Norwich Castle Museum, Small Stories exhibition - Tasha Winton"},
                   { "filename":"images/voyagers_images/V_Trip_to_Rana_Begum_at_the_Sainsbury_Centre7-Tasha_Winton.jpg","caption":""},
                   { "filename":"images/voyagers_images/V_Trip_to_Rana_Begum_at_the_Sainsbury_Centre-Tasha_Winton.jpg","caption":""},
                   { "filename":"images/voyagers_images/V_Visit_to_Groundwork_Gallery_Kings_Lynn_2_-_Laura_Drysdale_JPG.JPG","caption":"Visit to Groundwork Gallery King's Lynn - Restoration Trust"},
                   { "filename":"images/voyagers_images/V_Visit_to_Norwich_Castle_Museum_Small_stories_Exhibition_-_Laura_Drysdale.JPG","caption":"Visit to Norwich Castle Museum, Small Stories Exhibition - Restoration Trust"}
	             ]);
	});
	it("V, VideoName", function(){
		expect(pageData.projectData.videoName).toBe("");
	});
});

describe("BC, ProjectData:", function(){
	var pageData = new ProjectData("BC");
	it("BC, Should create new projectData", function() {
		expect(pageData.projectName).toBe("BC");
	});
	it("BC, Background image", function(){
		expect(pageData.projectData.backgroundImage).toBe("images/backgrounds/background-burgh-castle.jpg");
	});
	it("BC, Photo credit", function(){
		expect(pageData.projectData.photoCredit).toBe("Voyagers - Melanie Tilford");
	});
	it("BC, Logo file", function(){
		expect(pageData.projectData.logoFile).toBe("Report content/logos/BCAlogo.jpg");
	});
	it("BC, Logo link", function(){
		expect(pageData.projectData.logoLink).toBe("");
	});
	it("BC, About text", function(){
		expect(pageData.projectData.aboutText).toBe("<span class='heading'>Burgh Castle Almanac</span><br/>" +
        "Walking and creating for wellbeing at one of Britain’s greatest Roman forts<br/><br/><br/>" +
        "<span class='heading'>Partners</span><br/>" +
        "Norfolk Archeological Trust, Homegroup, Norfolk Museums Service");
	});
	it("BC Statistics", function(){
		expect(pageData.projectData.statistics).toEqual([{"stat":"4","context":" Sessions"},
                   {"stat":"8","context":" Participants"},
                   {"stat":"2","context":" people went to a Naturally 7 gig in Norwich"},
                   {"stat":"£4,445","context":" Social value"}
                  ]);
	});
	it("BC, Footer1 stuff", function(){
		expect(pageData.projectData.footer1html).toBe("");
	});
	it("BC, Footer2 stuff", function(){
		expect(pageData.projectData.footer2html).toBe("");
	});
	it("BC, Footer3 stuff", function(){
		expect(pageData.projectData.footer3html).toBe("");
	});
	it("BC, Gallery", function(){
		expect(pageData.projectData.gallery).toEqual([
                   { "filename":"images/burgh_castle_almanac_images/BCA_at_Festival_of_Archaeology_day_Burgh_Castle_-_Laura_Drysdale.jpg","caption":"BCA at Festival of Archaeology - Restoration Trust"},
                   { "filename":"images/burgh_castle_almanac_images/BCA_Creative_Photography-_Laura_Drysdale.jpg","caption":"Creative Photography - Restoration Trust"},
                   { "filename":"images/burgh_castle_almanac_images/BCA_Group_at_Burgh_Castle_Roman_Fort_-_Laura_Drysdale.jpg","caption":"Group at Burgh Castle - Restoration Trust"},
                   { "filename":"images/burgh_castle_almanac_images/BCA_Photography_at_Burgh_Castle_Church_-_Laura_Drysdale.jpg","caption":"Photography at Burgh Castle Church - Restoration Trust"},
                   { "filename":"images/burgh_castle_almanac_images/BCA_Photography_in_Time_and_Tide_Museum_-_Laura_Drysdale.jpg","caption":"Photography in Time and Tide Museum - Restoration Trust"},
                   { "filename":"images/burgh_castle_almanac_images/BCA_photos_edited_and_printed_June_2016.jpg","caption":"BCA final photos edited and printed - Restoration Trust"}
	            ]);
	});
});

describe("CM, ProjectData:", function(){
	var pageData = new ProjectData("CM");
	it("CM, Should create new projectData", function() {
		expect(pageData.projectName).toBe("CM");
	});
	it("CM, Background image", function(){
		expect(pageData.projectData.backgroundImage).toBe("images/backgrounds/background-change-minds.jpg");
	});
	it("CM, Photo credit", function(){
		expect(pageData.projectData.photoCredit).toBe("Change Minds - Norfolk Record Office");
	});
	it("CM, Logo file", function(){
		expect(pageData.projectData.logoFile).toBe("Report content/logos/change minds logo copy (1).jpg");
	});
	it("CM, Logo link", function(){
		expect(pageData.projectData.logoLink).toBe("http://changeminds.org.uk");
	});
	it("CM, About text", function(){
		expect(pageData.projectData.aboutText).toBe("<span class='heading'>Change Minds</span><br/>" +
        "Exploring mental health a hundred years ago and today<br/><br/>" +
        "<span class='heading'>Partners</span><br/>" +
        "Norfolk Record Office, Norfolk Library and Information Service, Together," +
        "Norfolk and Suffolk Foundation Trust, University of East Anglia");
	});
	it("CM, Statistics", function(){
		expect(pageData.projectData.statistics).toEqual([
                   {"stat":"22","context":" Sessions"},
                   {"stat":"18","context":" Participants"},
                   {"stat":"3","context":" Volunteers"},
                   {"stat":"800,000","context":" households read about Change Minds in Your Voice Norfolk"},
                   {"stat":"£373,255","context":" Social value"}
                  ]);
	});
	it("CM, Sound file", function(){
		expect(pageData.projectData.soundFile).toBe("Ute For change Minds.wav");
	});
	it("CM, Video file", function(){
		expect(pageData.projectData.videoFile).toBe("");
	});
	it("CM, Footer1 stuff", function(){
		expect(pageData.projectData.footer1html).toBe("");
	});
	it("CM, Footer2 stuff", function(){
		expect(pageData.projectData.footer2html).toBe("");
	});
	it("CM, Footer3 stuff", function(){
		expect(pageData.projectData.footer3html).toBe("");
	});
	it("CM, Gallery", function(){
		expect(pageData.projectData.gallery).toEqual([
                  { "filename":"images/change_mind_images/CM_book_binding_workshop_2_-_Dave_Pullin.jpg","caption":"Book binding workshop - Dave Pullin"},
                  { "filename":"images/change_mind_images/CM_book_mking_workshop_-_Laura_Drysdale.JPG","caption":"Book making workshop - Restoration Trust"},
                  { "filename":"images/change_mind_images/CM_Change_Minds_pop-up_exhibition_-_Restoration_Trust.jpg","caption":"Pop-up exhibition at Norfolk Record Office - Restoration Trust"},
                  { "filename":"images/change_mind_images/CM_with_RT_Hon_Norman_Lamb_MP_-_Laura_Drysdale.JPG","caption":"Visit by  Rt Hon Norman Lamb MP - Restoration Trust"},
                  { "filename":"images/change_mind_images/CM_Cohort_1_Quilt_Making_-_EDP_pic.jpg","caption":"Quilt making - Eastern Daily Press"},
                  { "filename":"images/change_mind_images/CM_Cohort1_Bookbinding_workshop_with_Nick_Sellwood_-_Helen_Sabberton.jpg","caption":"Bookbinding workshop with Nick Sellwood - Helen Sabberton"},
                  { "filename":"images/change_mind_images/CM_Cohort1Artwork-HelenSabberton.jpg","caption":"Group 1 art books  - Helen Sabberton"},
                  { "filename":"images/change_mind_images/CM_Cohorts_1&2_Participants_get_up_close_to_Lorina_Bulwers_embroided_letters_at_the_Shirehall_Study_Centre.jpg","caption":"Participants get up close to Lorina  Bulwer's embroidered letters at the Shirehall Study Centre"},
                  { "filename":"images/change_mind_images/CM_Mary_Macro_-_Norfolk_Record_Office.jpg","caption":"Mary Macro - Norfolk Record Office"},
                  { "filename":"images/change_mind_images/CM_Mary_Macro_-_Restoration_Trust.jpg","caption":"Mary Macro - Restoration Trust"},
                  { "filename":"images/change_mind_images/CM_Partipant_artwork_2_-_Tasha_Winton.jpg","caption":"Art by Karen Cletheroe - Tasha Winton"},
                  { "filename":"images/change_mind_images/CM_Site_of_St_Andrews_Hospital_today_-_Laura_Drysdale.JPG","caption":"Site of St Andrews Hospital today - Restoration Trust"},
                  { "filename":"images/change_mind_images/CM_Veronica_Medler_poem.JPG","caption":"Poem by Veronica Medler - Restoration Trust"}
	            ]);
	});
});

describe("CQ, ProjectData:", function(){
	var pageData = new ProjectData("CQ");
	it("CQ, Should create new projectData", function() {
		expect(pageData.projectName).toBe("CQ");
	});
	it("CQ, Background image", function(){
		expect(pageData.projectData.backgroundImage).toBe("images/backgrounds/background-culture-quest.png");
	});
	it("CQ, Photo credit", function(){
		expect(pageData.projectData.photoCredit).toBe("Culture Quest - Restoration Trust");
	});
	it("CQ, Logo file", function(){
		expect(pageData.projectData.logoFile).toBe("Report content/logos/CQ_Logo_CMYK_30.png");
	});
	it("CQ, Logo link", function(){
		expect(pageData.projectData.logoLink).toBe("https://culturequest.org.uk");
	});
	it("CQ, About text", function(){
		expect(pageData.projectData.aboutText).toBe("<span class='heading'>Culture Quest</span><br/>" +
        "Shared listening to music chosen by group members<br/><br/>" +
        "<span class='heading'>Partners</span><br/>" + 
        "Norwich Arts Centre, Julian Support, University of East Anglia" +
       "</ul>");
       });
       it("CQ, Statistics", function(){
       		expect(pageData.projectData.statistics).toEqual([
                     {"stat":"39","context":"Sessions"},
                     {"stat":"19","context":"Participants"},
                     {"stat":"4","context":"people went to a Naturally 7 gig in Norwich"},
                     {"stat":"£64,630","context":" Social value"}
                  ]);
       });
	it("CQ, Sound File", function(){
		expect(pageData.projectData.soundFile).toBe("Georgia. M.wav");
	});
	it("CQ, Footer1 stuff", function(){
		expect(pageData.projectData.footer1html).toBe("");
	});
	it("CQ, Footer2 stuff", function(){
		expect(pageData.projectData.footer2html).toBe("");
	});
	it("CQ, Footer3 stuff", function(){
		expect(pageData.projectData.footer3html).toBe("");
	});
	it("CQ, Social media links", function(){
		expect(pageData.projectData.SocialMediaLinks).toBe("");
	});
});
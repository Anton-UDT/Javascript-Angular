describe("GalleryViewer", function(){
	var jsonFile = ["images/human_henge_images/hh_neolithic_houses2.jpg",
	"images/human_henge_images/hh_pottery_workshop.jpg",
	"images/human_henge_images/hh_winter_solstice_ceremony.jpg"];
	
	
	it("Should get the json data", function(){
		gallery = new GalleryViewer(jsonFile);
		expect(gallery.imageFile).not.toBe(undefined);
	});
	
	it("Index should start with 0", function(){
		gallery = new GalleryViewer(jsonFile);
	 	expect(gallery.index).toBe(0);
	});
	
	it("Get first image", function(){
		gallery = new GalleryViewer(jsonFile);
		currImage = gallery.getCurrImage();
		expect(currImage).toBe("images/human_henge_images/hh_neolithic_houses2.jpg");
	})
	
	it("Should advance to next slide", function(){
		gallery = new GalleryViewer(jsonFile);
		gallery.advanceNextImg();
		currImage = gallery.getCurrImage();
		expect(currImage).toBe("images/human_henge_images/hh_pottery_workshop.jpg");

	});
	
	it("index return to 0 when reaches the end of array", function(){
		gallery = new GalleryViewer(jsonFile);
		gallery.advanceNextImg();
		gallery.advanceNextImg();
		gallery.advanceNextImg();
		currImage = gallery.getCurrImage();
		expect(currImage).toBe("images/human_henge_images/hh_neolithic_houses2.jpg");
	});
	
});